# Bulletin - Expense receipt naming convention

**Organization:** BrightDock Retail
**Bulletin ID:** RTN-COR-018-07-TRN
**Owner:** Finance Operations
**Session date:** May 18, 2026
**Format:** short refresher / attendance tracked

## Purpose

This bulletin covers a routine refresher for staff who handle **Expense receipt naming convention**. It is intended to reduce small process errors around the **receipt folder**, especially when coverage changes or new staff are helping at the **expense workspace**. This is an ordinary file naming record for BrightDock Retail. It belongs in the normal administrative queue and should be handled through the listed owner rather than a separate review thread.

## Learning Points

| Topic | Detail | Completion evidence |
|---|---|---|
| Reference copy | Where the current file is stored and how it is named. | Staff initials in portal |
| Corrections | How to record ordinary corrections without duplicate files. | One sample correction |
| Queue routing | Which queue handles access, scheduling, or supply questions. | Link to financeops@brightdockretail.com |
| Team handoff | When a team leader should mention the item in huddle. | Huddle note |

## Completion Instructions

Participants should acknowledge the bulletin in the learning portal by the end of the week. Questions about attendance credit should go to financeops@brightdockretail.com; questions about local practice should stay with the team leader for the relevant unit.

## Facilitator Note

Do not collect personal notes or screenshots for this refresher. The expected evidence is the normal completion checkbox and, if needed, a short comment that the staff member knows where to find the **receipt folder**.
