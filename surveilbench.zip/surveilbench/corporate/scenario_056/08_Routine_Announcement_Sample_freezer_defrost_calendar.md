# Announcement - Sample freezer defrost calendar

**Organization:** Granite Watch Labs
**Posting unit:** Lab Operations
**Announcement ID:** RTN-COR-056-08-ANN
**Posted:** March 29, 2026
**Audience:** staff using the sample storage room

## Notice

Operations is posting a routine announcement about **Sample freezer defrost calendar**. The current plan is to keep the **freezer calendar** available in the usual location and to route ordinary questions through labops@granitewatchlabs.com. This is an ordinary lab housekeeping record for Granite Watch Labs. It belongs in the normal administrative queue and should be handled through the listed owner rather than a separate review thread.

## What changes

| Area | Current handling | Owner |
|---|---|---|
| Posted copy | Refresh the visible copy near the sample storage room. | Hannah Ortiz |
| Archive | Keep last cycle's copy in the shared archive folder. | Julian Cross |
| Questions | Send corrections or access questions to labops@granitewatchlabs.com. | Lab Operations |
| Digest line | Include one sentence in the weekly staff note if space allows. | Leah Morgan |

## Staff note

Staff should not create a parallel spreadsheet or message thread for this item. If the posted copy looks wrong, send the exact location, asset tag, or calendar entry to labops@granitewatchlabs.com. The update is expected to be complete during the normal administrative window, and no special review meeting is scheduled.

## Closeout

Operations will mark the announcement closed after the visible copy and archived copy match. Late edits can be held for the next routine refresh unless they prevent staff from finding the **freezer calendar**.
