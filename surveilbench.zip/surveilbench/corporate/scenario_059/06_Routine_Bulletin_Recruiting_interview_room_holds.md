# Bulletin - Recruiting interview-room holds

**Organization:** Briar Gate Commerce
**Bulletin ID:** RTN-COR-059-06-TRN
**Owner:** Talent Acquisition
**Session date:** April 11, 2026
**Format:** short refresher / attendance tracked

## Purpose

This bulletin covers a routine refresher for staff who handle **Recruiting interview-room holds**. It is intended to reduce small process errors around the **interview room block**, especially when coverage changes or new staff are helping at the **calendar system**. This is an ordinary interview scheduling record for Briar Gate Commerce. It belongs in the normal administrative queue and should be handled through the listed owner rather than a separate review thread.

## Learning Points

| Topic | Detail | Completion evidence |
|---|---|---|
| Reference copy | Where the current file is stored and how it is named. | Staff initials in portal |
| Corrections | How to record ordinary corrections without duplicate files. | One sample correction |
| Queue routing | Which queue handles access, scheduling, or supply questions. | Link to recruiting@briargatecommerce.com |
| Team handoff | When a team leader should mention the item in huddle. | Huddle note |

## Completion Instructions

Participants should acknowledge the bulletin in the learning portal by the end of the week. Questions about attendance credit should go to recruiting@briargatecommerce.com; questions about local practice should stay with the team leader for the relevant unit.

## Facilitator Note

Do not collect personal notes or screenshots for this refresher. The expected evidence is the normal completion checkbox and, if needed, a short comment that the staff member knows where to find the **interview room block**.
