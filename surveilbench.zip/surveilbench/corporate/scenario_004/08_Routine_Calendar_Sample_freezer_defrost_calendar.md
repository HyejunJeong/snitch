# Calendar - Sample freezer defrost calendar

**Organization:** Kestrel Solvents
**Coordinator:** Lab Operations
**Schedule ID:** RTN-COR-004-08-SCH
**Week of:** February 13, 2026
**Location:** sample storage room

## Weekly Plan

| Time block | Item | Owner | Notes |
|---|---|---|---|
| Monday 9:00 AM | Check current **freezer calendar**. | Elena Park | Confirm the posted copy is legible. |
| Tuesday 1:00 PM | Staff reminder. | Marcus Reed | Mention normal routing during huddle. |
| Wednesday 11:30 AM | Queue review. | Talia Chen | Close duplicate requests. |
| Thursday 2:00 PM | Owner confirmation. | Drew Kaplan | Compare the visible copy to the shared file. |
| Friday 3:00 PM | Archive prior copy. | Nora Blake | Keep the final copy in the shared folder. |

## Coordination Notes

This schedule is for ordinary coverage and administrative cleanup at Kestrel Solvents. It does not change operational policy or create a new review file. If timing changes, update the shared calendar and notify labops@kestrelsolvents.com. Do not create a separate tracking sheet unless Lab Operations asks for one.

## Handoff

The team leader should verify that the Friday archive step is complete. If the **sample storage room** is unavailable, move the posted copy to the temporary desk and leave a note in the same calendar thread.
