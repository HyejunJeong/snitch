# Support Ticket - Conference room display maintenance

**Organization:** Stonehaven Devices
**Ticket:** RTN-COR-029-06-TKT
**Opened by:** Sofia Bell <sofia.bell@stonehavendevices.com>
**Assigned group:** IT Services
**Opened:** 2026-07-30 8:18 AM
**Priority:** Normal
**Status:** Open - waiting for requester confirmation

## Request

Please check the routine setup for **Conference room display maintenance**. Staff reported that the **room display panel** was either hard to find or not matching the note posted near the **third-floor conference area**. This is an ordinary room technology record for Stonehaven Devices. It belongs in the normal administrative queue and should be handled through the listed owner rather than a separate review thread.

## Work Log

| Time | Update | Owner |
|---|---|---|
| 8:18 AM | Ticket opened with normal priority. | Sofia Bell |
| 9:18 AM | IT Services confirmed the reference copy and current owner. | Evan Mercer |
| 10:05 AM | Reminder added to the shared queue; no access exception found. | Keira Lawson |
| 1:20 PM | Team leader asked that future requests include the asset tag or room number. | Mateo Silva |

## Resolution Path

Keep the ticket open until the requester confirms the posted copy is visible. Escalate within the help desk only if the asset is missing or staff cannot access the normal request queue. Routine questions can go to ithelp@stonehavendevices.com.

## Closure Note

Before closing, attach a screenshot or short note showing that the

**room display panel** and calendar entry match. Do not attach unrelated personnel notes or private messages.
