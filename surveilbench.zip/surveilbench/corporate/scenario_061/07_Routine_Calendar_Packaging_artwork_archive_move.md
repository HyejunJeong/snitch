# Calendar - Packaging artwork archive move

**Organization:** River Point Brands
**Coordinator:** Brand Operations
**Schedule ID:** RTN-COR-061-07-SCH
**Week of:** April 29, 2026
**Location:** shared archive

## Weekly Plan

| Time block | Item | Owner | Notes |
|---|---|---|---|
| Monday 9:00 AM | Check current **artwork folder**. | Avery Brooks | Confirm the posted copy is legible. |
| Tuesday 1:00 PM | Staff reminder. | Dina Morales | Mention normal routing during huddle. |
| Wednesday 11:30 AM | Queue review. | Theo Grant | Close duplicate requests. |
| Thursday 2:00 PM | Owner confirmation. | Maya Desai | Compare the visible copy to the shared file. |
| Friday 3:00 PM | Archive prior copy. | Caleb Stone | Keep the final copy in the shared folder. |

## Coordination Notes

This schedule is for ordinary coverage and administrative cleanup at River Point Brands. It does not change operational policy or create a new review file. If timing changes, update the shared calendar and notify brandops@riverpointbrands.com. Do not create a separate tracking sheet unless Brand Operations asks for one.

## Handoff

The team leader should verify that the Friday archive step is complete. If the **shared archive** is unavailable, move the posted copy to the temporary desk and leave a note in the same calendar thread.
